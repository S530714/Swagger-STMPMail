package com.example.demo;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {
	

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		
	}

}

